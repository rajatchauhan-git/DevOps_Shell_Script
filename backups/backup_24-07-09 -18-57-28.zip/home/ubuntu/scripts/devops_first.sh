#!/bin/bash

echo "I will be a great DevOps Engineer"

#echo $bash

name="Jerry"

echo "Hello ${name},please enter your age"

read age

echo "My age is, ${age}"

echo "Sub: hello $1"

sleep 2

echo "Me: RAM RAM"

sleep 2

echo "please do RAM RAM"

