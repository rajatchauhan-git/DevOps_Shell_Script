#!/bin/bash


<<readme
this script takes backup of directory
usage:
./backup.sh <path of directory>
readme

source_dir=$1

timestamp=$(date '+%y-%m-%d -%H-%M-%S')

backup_dir="${source_dir}/backup_${timestamp}"

zip -r "${backup_dir}.zip" "${source_dir}"


if [ $? -eq 0 ]; then 
#$? -eq 0 is used to check if above commant runs successfully
	echo "Backup created successfully"
else
	echo "Backup was not preformed for $timestamp"
fi


