#!/bin/bash

if [ "$1" = "like" ]
then
	echo "Hey please like this video"
else
	echo "Okay, then please subs"
fi

